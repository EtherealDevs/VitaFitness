"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Settings, Users, FileText, BarChart2 } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

const navigation = [
  { name: "Inicio", href: "/dashboard", icon: Home },
  { name: "Alumnos", href: "/dashboard/alumnos", icon: Users },
  { name: "Permisos", href: "/dashboard/permisos", icon: FileText },
  { name: "Estadísticas", href: "/dashboard/estadisticas", icon: BarChart2 },
  { name: "Configuración", href: "/dashboard/configuracion", icon: Settings },
]

export function DashboardNav() {
  const pathname = usePathname()

  return (
    <nav className="grid gap-1">
      {navigation.map((item) => {
        const Icon = item.icon
        return (
          <Button
            key={item.href}
            variant={pathname === item.href ? "secondary" : "ghost"}
            className={cn("w-full justify-start gap-2", pathname === item.href && "bg-secondary")}
            asChild
          >
            <Link href={item.href}>
              <Icon className="h-4 w-4" />
              {item.name}
            </Link>
          </Button>
        )
      })}
    </nav>
  )
}

