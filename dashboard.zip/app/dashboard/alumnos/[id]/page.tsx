"use client"
import { Calendar } from "@/components/ui/calendar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"

export default function StudentProfile({ params }: { params: { id: string } }) {
  // En una aplicación real, aquí obtendrías los datos del alumno usando el ID
  const student = {
    id: params.id,
    name: "Juan Pérez",
    status: "ACTIVO",
    statusCode: "AL-205",
    classes: [
      { name: "LBM", time: "10:00" },
      { name: "PILATES", time: "11:00" },
      { name: "FUNCIONAL", time: "12:00" },
      { name: "BICI", time: "13:00" },
    ],
  }

  return (
    <div className="container py-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">{student.name}</h1>
        <Button variant="destructive">Cancelar Plan</Button>
      </div>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Estado</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Estado Actual</span>
                <Badge variant="success">{student.status}</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Código</span>
                <span>{student.statusCode}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Clases</CardTitle>
          </CardHeader>
          <CardContent>
            <Calendar mode="single" className="rounded-md border" />
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Clases Previas</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
              {student.classes.map((clase) => (
                <div key={clase.name} className="rounded-lg border p-3 text-center">
                  <h3 className="font-semibold">{clase.name}</h3>
                  <p className="text-sm text-muted-foreground">{clase.time}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

